package org.ukrida.root.ui.user.screens.groupmenus.dailybread.screen

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import org.ukrida.root.ui.user.components.PublicBottomNavigation
import org.ukrida.root.ui.user.components.PublicDestination
import org.ukrida.root.ui.user.navigation.PublicScreen
import org.ukrida.root.ui.user.components.DashboardMenu
import org.ukrida.root.ui.user.components.DashboardTopBar
import org.ukrida.root.ui.user.screens.groupmenus.dailybread.components.DevotionCard
import org.ukrida.root.ui.user.screens.groupmenus.dailybread.viewmodel.DailyBreadViewModel

@Composable
fun DailyBreadScreen(
    navController: NavHostController,
    groupId: Int
) {
    val viewModel: DailyBreadViewModel = viewModel()
    val devotions by viewModel.devotions.collectAsState()
    var expanded by remember {
        mutableStateOf(false)
    }
    LaunchedEffect(groupId) {
        viewModel.loadDevotions(groupId)
    }
    Scaffold(
        containerColor = Color(0xFF2A2522),
        bottomBar = {
            PublicBottomNavigation(
                currentDestination = PublicDestination.GROUP,
                onNavigate = { destination ->
                    when(destination){
                        PublicDestination.HOME ->
                            navController.navigate(PublicScreen.Home.route)
                        PublicDestination.PROMISED_LAND ->
                            navController.navigate(PublicScreen.PromisedLand.route)
                        PublicDestination.GROUP ->
                            navController.popBackStack()
                        PublicDestination.PROFILE ->
                            navController.navigate(PublicScreen.Profile.route)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFF2A2522))
        ) {
            DashboardTopBar(
                title = "DAILY BREAD",
                expanded = expanded,
                onExpandClick = {
                    expanded = !expanded
                }
            )
            Column(
                modifier = Modifier.padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Daily Bread",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFE8D8C9),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Read and reflect on today's devotion.",
                    color = Color.White.copy(alpha = .8f),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(20.dp))
            }
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(
                    horizontal = 20.dp,
                    vertical = 8.dp
                ),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                itemsIndexed(devotions) { index, devotion ->
                    Text(
                        text = "DAY ${String.format("%02d", index + 1)}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE8D8C9)
                    )
                    DevotionCard(
                        devotion = devotion,
                        onClick = {
                            navController.navigate(
                                PublicScreen.DailyBreadDetail.createRoute(
                                    groupId,
                                    devotion.date
                                )
                            )
                        }
                    )
                }
            }
        }
        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = .4f))
                    .clickable(
                        indication = null,
                        interactionSource = remember {
                            MutableInteractionSource()
                        }
                    ) {
                        expanded = false
                    }
            )
        }
        if (expanded) {
            DashboardMenu(
                onDashboardClick = {
                    expanded = false
                    navController.navigate(
                        PublicScreen.Dashboard.createRoute(groupId)
                    )
                },
                onItineraryClick = {
                    expanded = false
                    navController.navigate(
                        PublicScreen.Itinerary.createRoute(groupId)
                    )
                },
                onHymnClick = {
                    expanded = false
                    navController.navigate(
                        PublicScreen.Hymn.createRoute(groupId)
                    )
                },
                onDailyBreadClick = {
                    expanded = false
                },
                onJournalClick = {
                    expanded = false
                    navController.navigate(
                        PublicScreen.Journal.createRoute(groupId)
                    )
                },
                onGalleryClick = {
                    expanded = false
                    navController.navigate(
                        PublicScreen.Gallery.createRoute(groupId)
                    )
                },
                onMembersClick = {
                    expanded = false
                    navController.navigate(
                        PublicScreen.Members.createRoute(groupId)
                    )
                }
            )
        }
    }
}